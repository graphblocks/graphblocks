# GraphBlocks v1.0 Implementation Plan

## 1. 목표

이 계획의 목표는 v1.0 명세를 기능 목록 순서가 아니라 **실행 가능한 vertical slice와 적합성 프로필 순서**로 구현하는 것이다. 초기부터 모든 provider, parser, connector, Kubernetes operator를 구현하지 않는다. Core semantics와 TCK가 먼저다.

## 2. Repository 구조

```text
graphblocks/
├─ crates/
│  ├─ graphblocks-schema
│  ├─ graphblocks-core
│  ├─ graphblocks-runtime
│  ├─ graphblocks-journal
│  ├─ graphblocks-protocol
│  ├─ graphblocks-python
│  └─ graphblocksd
├─ python/
│  ├─ graphblocks-core
│  ├─ graphblocks-stdlib
│  ├─ graphblocks-documents
│  ├─ graphblocks-rag
│  ├─ graphblocks-conversation
│  ├─ graphblocks-policy
│  ├─ graphblocks-budget
│  ├─ graphblocks-usage
│  └─ optional packages
├─ schemas/
├─ tck/
├─ acceptance/
├─ deployment/
└─ docs/
```

Rust core crate는 PyO3에 의존하지 않는다. `graphblocks-python`만 PyO3와 async bridge를 소유한다.

## 3. Phase 0 — Contract Toolchain (`GB-C0-SCHEMA`)

### 구현

- canonical schema registry와 schema ID/version 규칙
- GraphSpec/ApplicationSpec/BindingSpec parse, validation, normalization
- normalized IR canonical serialization과 content hash
- BlockDescriptor, typed port, resource slot, implementation manifest
- migration reader: v1alpha1/v1alpha2 → v1alpha3
- Python Pydantic/type stub과 Rust serde type 동등성 검사
- `graphblocks validate`, `plan`, `migrate`, `plugins list`
- schema/compiler TCK harness

### 첫 package

```text
graphblocks-core
graphblocks-stdlib
graphblocks-testing
graphblocks-cli
```

### 종료 기준

- 동일 입력은 플랫폼과 map ordering에 관계없이 동일 normalized hash를 만든다.
- canonical value JSON round trip이 Rust/Python에서 동일하다.
- port mismatch, dead node, optional-output misuse, ambiguous binding을 compile 시 탐지한다.
- plugin manifest를 import 없이 탐색하고 충돌을 결정론적으로 거부한다.

## 4. Phase 1 — Local Rust Runtime (`GB-C1-LOCAL-RUNTIME`)

### 구현

- Tokio scheduler와 dependency readiness
- typed receive/send port와 bounded channel
- `Outcome<T>` terminal model
- structured cancellation과 resource scope
- timeout, retry, idempotency boundary
- local semaphore/rate limit/lease
- RunStore와 ExecutionJournal의 in-memory/SQLite reference backend
- state patch와 CAS
- finite sequence map/batch/task group
- Python binding과 Python in-process/worker adapter
- deterministic InProcessTestRuntime

### 첫 vertical slice

```text
Message
→ prompt.render
→ scripted model.generate
→ Answer
→ conversation.begin/commit
→ ExecutionJournal
```

### 종료 기준

- single terminal, cancel idempotency, no-output-after-terminal TCK 통과
- partial output 후 unsafe retry를 거부한다.
- process shutdown 시 lease와 task가 남지 않는다.
- Python callback이 존재해도 scheduler ownership은 Rust에 남는다.

## 5. Phase 2 — AI Core Profiles (`GB-C2-AI-APPLICATION`)

### Documents

- Artifact/SourceAsset/Revision/ParsedDocument/Element/Chunk
- MIME routing과 parser plugin SPI
- deterministic parser selection lock
- OCR fallback interface
- lineage, manifest, delete/tombstone
- BlobStore local/S3-compatible reference adapter

### RAG

- Retriever/SearchRequest/SearchHit/KnowledgeItemRef
- dense/keyword federation and RRF
- reranker SPI
- ContextPack budget and provenance
- Answer/Claim/Citation validation and abstention

### Conversation

- Conversation/Turn/Message/ContentPart
- begin/abort/commit transaction
- draft delta, committed, retracted
- attachment scope and memory compaction policy
- Application command/event protocol

### Acceptance applications

- direct multi-format file analysis
- incremental document ingestion
- federated enterprise RAG
- multi-turn attachment chatbot

### 종료 기준

- source location이 file→element→chunk→retrieval→claim→citation으로 resolve된다.
- ACL이 chunk/index/retrieval/citation에 전파된다.
- branch에서 `Absent`와 `Value(null)`이 구분된다.
- conversation CAS conflict와 regenerate/branch가 결정론적으로 처리된다.

## 6. Phase 3 — Policy, Usage, Budget, Evaluation (`GB-C3-GOVERNED-RUNTIME`)

### 구현

- PolicyBundle/Profile/Snapshot, PAP/PIP/PDP/PEP
- typed obligations와 decision/enforcement record 분리
- UsageLedger와 BudgetLedger
- hierarchical atomic reservation
- bounded BudgetPermit와 fencing
- provider usage provisional/settlement/reconciliation
- completion reserve
- `finish_current_turn`, `hard_stop`, `checkpoint_and_pause`, `degrade_then_finalize`
- Approval과 Review 분리
- Check/Metric/Gate/Trial/ResultBundle
- local SQLite backend와 race/fault TCK

### 핵심 시험

```text
A. quota threshold를 generation 중 초과
B. provider cancel 미지원
C. 늦은 final usage 도착
D. effect commit critical section 진입
E. parallel task가 동시에 마지막 budget을 reserve
```

### 종료 기준

- oversubscription이 허용된 overdraft를 넘지 않는다.
- finish-current-turn은 declared continuation envelope 밖의 새 work를 시작하지 않는다.
- hard-stop 이후 승인된 sequence를 넘는 delta가 client/durable state에 commit되지 않는다.
- telemetry outage가 quota, audit, recovery correctness에 영향을 주지 않는다.

## 7. Phase 4 — Packaging, Integrations, Observability

### Packaging

- Maturin mixed Rust/Python wheel
- foundation release train
- independent first-party extension SemVer
- static entry-point manifest와 lazy loading
- package closure/lock/doctor
- SBOM, license, vulnerability and signature pipeline

### 첫 integrations

```text
model provider: one OpenAI-compatible adapter + scripted provider
parser: PDF + plain text
retriever: local/in-memory + Qdrant adapter
blob: local + S3-compatible
record/state: SQLite/Postgres
telemetry: OTLP
LLM observability: Langfuse adapter
interoperability: Haystack Component/Pipeline adapter
```

### Observability

- canonical observation model
- versioned OTel mapping adapter
- Langfuse telemetry/prompt/evaluation/dataset SPI
- capture/redaction before all exporters
- low-cardinality metric linter
- diagnostic bundle

### 종료 기준

- `pip install graphblocks`에 provider/parser/cloud SDK가 포함되지 않는다.
- plugin discovery만으로 heavy SDK가 import되지 않는다.
- Langfuse/OTLP failure가 run을 실패시키지 않는다.
- AuditLog와 UsageLedger는 lossy exporter를 사용하지 않는다.

## 8. Phase 5 — Remote Workers, Release, Deployment (`GB-C4-PRODUCTION`)

### 구현

- versioned worker protocol와 WorkerAdvertisement
- remote edge serialization, ArtifactRef transfer, trace/policy/budget context propagation
- RunOwnershipLease와 fencing
- immutable GraphRelease/DeploymentRevision/PhysicalExecutionPlan
- OCI bundle, image/package/prompt/policy/index lock
- worker drain and in-flight upgrade policy
- Kubernetes/Helm renderer
- Terraform requirements/output bridge
- canary/shadow/rollback quality gates
- SLO and recovery profile

### target images

```text
control-plane
rag-cpu
document-cpu
ocr-gpu
sandbox
```

### 종료 기준

- incompatible package/protocol worker는 admission되지 않는다.
- remote boundary의 non-serializable 또는 oversized inline value를 compile 시 거부한다.
- old release의 conversation/job affinity를 보존하며 drain할 수 있다.
- signed release와 physical plan hash가 모든 run provenance에 남는다.

## 9. Phase 6 — Adaptive Orchestration and Verified Work (`GB-X1-ORCHESTRATION`)

### 구현

- bounded TaskPlan/TaskPlanPatch와 revision CAS
- ModelPool/WorkerProfile eligibility
- per-task budget reservation
- context-access graph
- ResourceSnapshot/ChangeSet workspace lifecycle
- isolated Trial, Check/Gate, Review, CAS commit
- LeasePool for scarce resources
- TUI client using Application Protocol

### Acceptance applications

- bounded multi-worker research orchestrator
- authority-backed advisory workflow with official source revalidation and substantive review
- verified workspace optimizer using RTL/Verilog as a fixture
- TUI workspace assistant

### 종료 기준

- model은 GraphSpec topology를 수정하지 않는다.
- TaskPlan limits, dependency acyclicity, context access, budget가 validation된다.
- trusted oracle/test/source는 candidate mutation에서 보호된다.
- review subject digest가 변경되면 review가 자동 무효화된다.

## 10. Phase 7 — Optional Extensions

### Voice (`GB-X2-VOICE`)

DuplexSession, transport, VAD authority, interruption classifier, playback ledger, provider realtime adapter를 별도 package에서 구현한다.

### Durable unbounded stream (`GB-X3-DURABLE-STREAM`)

offset, partition, watermark, late data, trigger, checkpoint barrier, idempotent sink commit이 필요한 경우에만 구현한다. 문서 ingestion의 finite per-item checkpoint와 혼동하지 않는다.

## 11. CI/CD와 품질 게이트

모든 PR:

```text
format/lint
Rust/Python unit tests
schema generation diff
canonical hash golden tests
TCK subset
package dependency closure
secret/content capture lint
license and vulnerability scan
```

Release candidate:

```text
full TCK
acceptance applications
fault/chaos tests
performance benchmark
wheel matrix
OCI image build
SBOM/provenance/signature
upgrade/downgrade migration tests
```

## 12. 초기 구현에서 의도적으로 하지 않을 것

- 모든 provider와 database 동시 지원
- Kubernetes operator부터 구현
- 범용 distributed stream engine
- arbitrary Python object serialization
- model이 graph topology를 직접 생성/수정
- domain-specific official package
- exactly-once라는 추상적 보장
- token delta별 telemetry span

## 13. 첫 backlog 순서

1. canonical schema repository와 IDs
2. normalized IR/hash
3. BlockDescriptor와 compiler diagnostics
4. Rust scheduler skeleton
5. journal/state/cancel TCK
6. PyO3 binding
7. scripted model + conversation vertical slice
8. document lineage + local parser adapter
9. local Retriever + RAG vertical slice
10. policy/budget/usage race tests
11. package/plugin manifest and lock
12. OTLP/Langfuse projection
13. Python worker protocol
14. immutable release/physical plan
15. Kubernetes renderer
16. TaskPlan/workspace trial
